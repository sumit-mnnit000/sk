#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>

char str1[] = "Hello";
char str2[] = " World!";
char result_final[100];

void concat_without_str_functions(char *str1, char *str2, char *result) {
    // Copy str1 to result
    int i = 0, j = 0;
    while (str1[i] != '\0') {
        result[i] = str1[i];
        i++;
    }
    // Append str2 to result
    while (str2[j] != '\0') {
        result[i] = str2[j];
        i++;
        j++;
    }
    result[i] = '\0'; // Null-terminate the resulting string
    //result_final = result;
}

int main()
{
int fd[2],n;
char buffer[100];
pid_t p;
pipe(fd); //creates a unidirectional pipe with two end fd[0] and fd[1]
p=fork();

if(p>0) //parent
{
	printf("Parent Passing value to child\n");
	write(fd[1],str1,sizeof(str1)); //fd[1] is the write end of the pipe
	wait(NULL);
}
else // child
{
	printf("Child printing received value\n");
	n=read(fd[0],buffer,sizeof(buffer)); //fd[0] is the read end of the pipe
	concat_without_str_functions(buffer, str2, result_final);
	write(1,result_final,100);
}
}
