#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define ROWS 2
#define COLS 2



void printMatrix(int matrix[ROWS][COLS]) {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

void add_matrices(int mat1[ROWS][COLS], int mat2[ROWS][COLS], int result[ROWS][COLS]) {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            result[i][j] = mat1[i][j] + mat2[i][j];
        }
    }
}

int main() {
    int matrixA[ROWS][COLS] = {{1, 2}, {3, 4}};
    int matrixB[ROWS][COLS] = {{5, 6}, {7, 8}};
        int matrixSum[ROWS][COLS];

    int pipefd[2];
    int pipefd2[2];

    // Create a single pipe
    if (pipe(pipefd) == -1) {
        perror("Pipe failed");
        exit(EXIT_FAILURE);
    }
    
    pipe(pipefd2);

    pid_t pid = fork();

    if (pid == -1) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    } else if (pid == 0) { // Child process
        int matA[ROWS][COLS], matB[ROWS][COLS], result[ROWS][COLS];

        // Read matrices from parent
        read(pipefd[0], matA, sizeof(matA));
        read(pipefd[0], matB, sizeof(matB));
        
        printMatrix(matA);
        printMatrix(matB);

        // Calculate the sum of matrices
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                result[i][j] = matA[i][j] + matB[i][j];
            }
        }
        
        printMatrix(result);

        // Send the result back to the parent
        write(pipefd2[1], result, sizeof(result));

        //exit(0);
    } else { // Parent process

        // Send matrices to child
        write(pipefd[1], matrixA, sizeof(matrixA));
        write(pipefd[1], matrixB, sizeof(matrixB));
        
        // Wait for child to complete
        //sleep(15);
        wait(NULL);
        
        //printMatrix(result);

        // Read the result from the child
        read(pipefd2[0], matrixSum, sizeof(matrixSum));

        // Print result
        printf("Matrix A:\n");
        printMatrix(matrixA);
        printf("Matrix B:\n");
        printMatrix(matrixB);
        printf("Sum of Matrices:\n");
        printMatrix(matrixSum);
    }

    return 0;
}

