import java.io.*;
import java.net.*;

public class UppercaseServer {
    public static void main(String[] args) {
        final int PORT = 8080;

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is running on port " + PORT + "...");

            while (true) {
                // Accept a client connection
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress().getHostAddress());

                // Handle client communication
                try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                     PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

                    // Read string from client
                    String inputString = in.readLine();
                    System.out.println("Received from client: " + inputString);

                    // Convert to uppercase
                    String upperCaseString = inputString.toUpperCase();

                    // Send back to client
                    out.println(upperCaseString);
                    System.out.println("Sent to client: " + upperCaseString);
                } catch (IOException e) {
                    System.err.println("Error handling client: " + e.getMessage());
                }

                clientSocket.close();
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }
}

