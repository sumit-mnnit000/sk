import java.io.*;
import java.net.*;

public class UppercaseClient {
    public static void main(String[] args) {
        final String SERVER_ADDRESS = "127.0.0.1"; // localhost
        final int SERVER_PORT = 8080;

        try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in))) {

            System.out.println("Connected to the server.");

            // Get input from user
            System.out.print("Enter a string to convert to uppercase: ");
            String inputString = userInput.readLine();

            // Send string to server
            out.println(inputString);

            // Receive uppercase string from server
            String upperCaseString = in.readLine();
            System.out.println("Uppercase string from server: " + upperCaseString);

        } catch (IOException e) {
            System.err.println("Client error: " + e.getMessage());
        }
    }
}

