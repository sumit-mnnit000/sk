#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>
#include <sys/sysinfo.h>

#define PORT 8080
#define BUFFER_SIZE 1024

// Function to get CPU load as a percentage
float get_cpu_load() {
    struct sysinfo sys_info;
    if (sysinfo(&sys_info) == 0) {
        double load = sys_info.loads[0] / 65536.0; // Get 1-minute load average
        return load * 100;
    }
    return -1; // Error case
}

// Function to get current date and time as a string
void get_datetime(char *buffer, size_t size) {
    time_t now = time(NULL);
    struct tm *local = localtime(&now);
    strftime(buffer, size, "%Y-%m-%d %H:%M:%S", local);
}

void handle_client(int client_socket) {
    char buffer[BUFFER_SIZE];
    char datetime[BUFFER_SIZE];
    float cpu_load;

    // Get date and time
    get_datetime(datetime, sizeof(datetime));

    // Get CPU load
    cpu_load = get_cpu_load();

    // Prepare response
    snprintf(buffer, sizeof(buffer),
             "Date & Time: %s\nCPU Load: %.2f%%\n",
             datetime, cpu_load);

    // Send response to client
    send(client_socket, buffer, strlen(buffer), 0);

    close(client_socket);
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);

    // Create socket
    if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind socket
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_socket, 5) < 0) {
        perror("Listen failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    printf("Server is running on port %d...\n", PORT);

    while (1) {
        // Accept new connection
        if ((client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &addr_len)) < 0) {
            perror("Accept failed");
            continue;
        }

        printf("New client connected.\n");

        // Handle client request
        handle_client(client_socket);
    }

    close(server_socket);
    return 0;
}

