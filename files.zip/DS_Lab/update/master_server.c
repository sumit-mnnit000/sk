#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024
#define MAX_CLIENTS 10

typedef struct {
    int node_no;
    char ip_address[16];
    int port_no;
} MasterTable;

MasterTable master_table[MAX_CLIENTS];
int master_count = 0;

void update_master_table(char *client_ip, int client_port) {
    master_table[master_count].node_no = master_count + 1;
    strncpy(master_table[master_count].ip_address, client_ip, 16);
    master_table[master_count].port_no = client_port;
    master_count++;
}

void send_master_table(int client_socket) {
    for (int i = 0; i < master_count; i++) {
        char entry[BUFFER_SIZE];
        snprintf(entry, sizeof(entry), "Node No: %d, IP: %s, Port: %d\n",
                 master_table[i].node_no,
                 master_table[i].ip_address,
                 master_table[i].port_no);
        send(client_socket, entry, strlen(entry), 0);
    }
    send(client_socket, "END\n", 4, 0); // Indicate end of table
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);

    // Create socket
    if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind socket
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_socket, 5) < 0) {
        perror("Listen failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    printf("Server is running on port %d...\n", PORT);

    while (1) {
        char client_ip[INET_ADDRSTRLEN];
        int client_port;

        // Accept new connection
        if ((client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &addr_len)) < 0) {
            perror("Accept failed");
            continue;
        }

        // Get client IP and port
        inet_ntop(AF_INET, &client_addr.sin_addr, client_ip, INET_ADDRSTRLEN);
        client_port = ntohs(client_addr.sin_port);

        printf("New connection from %s:%d\n", client_ip, client_port);

        // Update master table
        update_master_table(client_ip, client_port);

        // Send updated master table to client
        send_master_table(client_socket);

        close(client_socket);
    }

    close(server_socket);
    return 0;
}

