#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/sysinfo.h>

#define CLIENT_PORT 8080
#define SERVER1_PORT 9090
#define SERVER2_PORT 9091
#define BUFFER_SIZE 1024

// Function to get CPU load
float get_cpu_load() {
    struct sysinfo sys_info;
    if (sysinfo(&sys_info) == 0) {
        return (sys_info.loads[0] / 65536.0) * 100;
    }
    return -1; // Error case
}

// Function to connect to a server and send data
void communicate_with_server(const char *server_ip, int server_port, const char *input, char *output) {
    int sock;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];

    // Create socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(server_port);
    inet_pton(AF_INET, server_ip, &server_addr.sin_addr);

    // Connect to server
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection to server failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    // Send string to server
    send(sock, input, strlen(input), 0);

    // Receive response from server
    int bytes_received = recv(sock, buffer, BUFFER_SIZE - 1, 0);
    if (bytes_received > 0) {
        buffer[bytes_received] = '\0';
        strcpy(output, buffer);
    }

    close(sock);
}

int main() {
    int client_sock, load_balancer_sock;
    struct sockaddr_in client_addr, load_balancer_addr;
    socklen_t addr_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE], response[BUFFER_SIZE];

    // Create load balancer socket
    if ((load_balancer_sock = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    load_balancer_addr.sin_family = AF_INET;
    load_balancer_addr.sin_addr.s_addr = INADDR_ANY;
    load_balancer_addr.sin_port = htons(CLIENT_PORT);

    // Bind socket
    if (bind(load_balancer_sock, (struct sockaddr *)&load_balancer_addr, sizeof(load_balancer_addr)) < 0) {
        perror("Bind failed");
        close(load_balancer_sock);
        exit(EXIT_FAILURE);
    }

    // Listen for client connections
    if (listen(load_balancer_sock, 5) < 0) {
        perror("Listen failed");
        close(load_balancer_sock);
        exit(EXIT_FAILURE);
    }

    printf("Load Balancer running on port %d...\n", CLIENT_PORT);

    while (1) {
        // Accept client connection
        if ((client_sock = accept(load_balancer_sock, (struct sockaddr *)&client_addr, &addr_len)) < 0) {
            perror("Client connection failed");
            continue;
        }

        // Receive string from client
        int bytes_received = recv(client_sock, buffer, BUFFER_SIZE - 1, 0);
        if (bytes_received > 0) {
            buffer[bytes_received] = '\0';

            // Get CPU load for both servers
            float cpu_load_server1 = get_cpu_load();
            float cpu_load_server2 = get_cpu_load();

            // Choose the server with lower CPU load
            const char *server_ip = (cpu_load_server1 < cpu_load_server2) ? "127.0.0.1" : "127.0.0.1";
            int server_port = (cpu_load_server1 < cpu_load_server2) ? SERVER1_PORT : SERVER2_PORT;

            // Forward string to the selected server and get the response
            communicate_with_server(server_ip, server_port, buffer, response);

            // Send response back to client
            send(client_sock, response, strlen(response), 0);
        }

        close(client_sock);
    }

    close(load_balancer_sock);
    return 0;
}

