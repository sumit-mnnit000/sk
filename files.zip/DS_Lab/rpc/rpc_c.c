#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 8080
#define BUFFER_SIZE 1024

void write_file(int server_socket) {
    char buffer[BUFFER_SIZE];
    FILE *fp = fopen("received_file.txt", "w");
    if (fp == NULL) {
        perror("Error creating file");
        exit(EXIT_FAILURE);
    }

    while (1) {
        int bytes_received = recv(server_socket, buffer, BUFFER_SIZE, 0);
        if (bytes_received <= 0) {
            break;
        }
        fprintf(fp, "%s", buffer);
        bzero(buffer, BUFFER_SIZE);
    }
    fclose(fp);
    printf("File received successfully. Saved as 'received_file.txt'.\n");
}

int main() {
    int client_sock;
    struct sockaddr_in server_addr;
    char file_name[BUFFER_SIZE];

    // Create socket
    if ((client_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    // Connect to the server
    if (connect(client_sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection to server failed");
        close(client_sock);
        exit(EXIT_FAILURE);
    }
    printf("Connected to server.\n");

    // Send file request
    printf("Enter the file name to request: ");
    fgets(file_name, BUFFER_SIZE, stdin);
    file_name[strcspn(file_name, "\n")] = '\0'; // Remove newline character
    send(client_sock, file_name, strlen(file_name), 0);

    // Receive the file
    write_file(client_sock);

    close(client_sock);
    return 0;
}

