#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

void send_file(FILE *fp, int client_socket) {
    char buffer[BUFFER_SIZE];
    while (fgets(buffer, BUFFER_SIZE, fp) != NULL) {
        send(client_socket, buffer, strlen(buffer), 0);
        bzero(buffer, BUFFER_SIZE);
    }
}

int main() {
    int server_sock, client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    char file_name[BUFFER_SIZE];

    // Create socket
    if ((server_sock = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind socket
    if (bind(server_sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_sock, 5) < 0) {
        perror("Listen failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }

    printf("Server is running on port %d...\n", PORT);

    while (1) {
        // Accept a client connection
        if ((client_sock = accept(server_sock, (struct sockaddr *)&client_addr, &addr_len)) < 0) {
            perror("Client connection failed");
            continue;
        }
        printf("Client connected.\n");

        // Receive file name from client
        recv(client_sock, file_name, BUFFER_SIZE, 0);
        printf("File requested: %s\n", file_name);

        // Open the requested file
        FILE *fp = fopen(file_name, "r");
        if (fp == NULL) {
            perror("File not found");
            send(client_sock, "File not found", strlen("File not found"), 0);
        } else {
            send_file(fp, client_sock);
            printf("File sent successfully.\n");
            fclose(fp);
        }

        close(client_sock);
    }

    close(server_sock);
    return 0;
}

