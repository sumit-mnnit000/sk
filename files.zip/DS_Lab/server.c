#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <semaphore.h>
#include <pthread.h>

#define SHM_NAME "/counter_shm"
#define SHM_SIZE sizeof(int)

int main() {
    // Shared memory setup
    int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
    ftruncate(shm_fd, SHM_SIZE);

    // Map shared memory
    int *counter = mmap(NULL, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);

    // Initialize counter to 0
    *counter = 0;

    // Semaphore setup using sem_init (not named, local to the process)
    sem_t sem;
    sem_init(&sem, 1, 1); // 1 = semaphore is shared between processes, initial value 1 (unlocked)

    printf("Server is running...\n");

    // Server logic: increment counter 10 times with synchronization
    for (int i = 0; i < 10; i++) {
        sem_wait(&sem); // Wait (lock) semaphore

        (*counter)++; // Increment counter

        printf("Counter incremented to: %d\n", *counter);

        sem_post(&sem); // Post (unlock) semaphore

        sleep(1); // Simulate work
    }

    // Cleanup resources
    munmap(counter, SHM_SIZE);
    shm_unlink(SHM_NAME);
    sem_destroy(&sem); // Destroy the semaphore

    printf("Server finished.\n");

    return 0;
}

