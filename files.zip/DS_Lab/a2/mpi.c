#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define ARRAY_SIZE 1000

int main(int argc, char *argv[]) {
    int rank, size;
    int local_sum = 0, total_sum = 0;

    // Initialize MPI
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); // Process rank
    MPI_Comm_size(MPI_COMM_WORLD, &size); // Total number of processes

    int chunk_size = ARRAY_SIZE / size; // Size of each process's chunk
    int local_array[chunk_size];       // Local chunk for each process

    // Master process initializes the full array
    if (rank == 0) {
        int array[ARRAY_SIZE];
        for (int i = 0; i < ARRAY_SIZE; i++) {
            array[i] = i + 1; // Fill array: [1, 2, ..., ARRAY_SIZE]
        }
        // Distribute chunks to all processes
        MPI_Scatter(array, chunk_size, MPI_INT, local_array, chunk_size, MPI_INT, 0, MPI_COMM_WORLD);
    } else {
        // Receive scattered chunk
        MPI_Scatter(NULL, chunk_size, MPI_INT, local_array, chunk_size, MPI_INT, 0, MPI_COMM_WORLD);
    }

    // Compute local sum
    for (int i = 0; i < chunk_size; i++) {
        local_sum += local_array[i];
    }

    // Combine results in the master process
    MPI_Reduce(&local_sum, &total_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    // Master process prints the total sum
    if (rank == 0) {
        printf("Total sum: %d\n", total_sum);
    }

    // Finalize MPI
    MPI_Finalize();
    return 0;
}

