#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX_BUF 1024

int main() {
    int sock = 0;
    struct sockaddr_in server_address;
    char buffer[MAX_BUF] = {0};
    int num;

    // Creating socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket failed");
        return -1;
    }

    // Setting server address structure
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(PORT);

    // Convert IP address from text to binary form
    if (inet_pton(AF_INET, "127.0.0.1", &server_address.sin_addr) <= 0) {
        perror("Invalid address or address not supported");
        return -1;
    }

    // Connect to server
    if (connect(sock, (struct sockaddr *)&server_address, sizeof(server_address)) < 0) {
        perror("Connection failed");
        return -1;
    }

    // Input number from user
    printf("Enter a number to calculate factorial: ");
    scanf("%d", &num);

    // Send number to server
    sprintf(buffer, "%d", num);
    send(sock, buffer, strlen(buffer), 0);

    // Receive factorial result from server
    read(sock, buffer, sizeof(buffer));
    printf("Factorial of %d is: %s\n", num, buffer);

    // Close the socket
    close(sock);

    return 0;
}

