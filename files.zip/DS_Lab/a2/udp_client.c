#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>
// to run gcc -o udp_client udp_client.c
//./udp_client 127.0.0.1 8080

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <Server IP> <Server Port>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char *server_ip = argv[1];
    int server_port = atoi(argv[2]);

    // Create a UDP socket
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    // Set up the server address
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr)); // Zero out the structure
    server_addr.sin_family = AF_INET;            // IPv4
    server_addr.sin_port = htons(server_port);   // Convert port to network byte order

    if (inet_pton(AF_INET, server_ip, &server_addr.sin_addr) <= 0) {
        perror("Invalid server IP address");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    // Input message to send
    char buffer[BUFFER_SIZE];
    printf("Enter message to send: ");
    fgets(buffer, BUFFER_SIZE, stdin);

    // Send message to the server
    ssize_t sent_bytes = sendto(
        sockfd, buffer, strlen(buffer), 0,
        (struct sockaddr *)&server_addr, sizeof(server_addr));

    printf("Message sent to server: %s\n", buffer);

    // Close the socket
    close(sockfd);

    return 0;
}

