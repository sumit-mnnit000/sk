#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NUM_PROCESSES 3

// Lamport Logical Clock
void lamport_clock(int process_id, int event_id, int *logical_clock, int received_lc) {
    if (received_lc >= 0) { // Message received
        *logical_clock = (*logical_clock > received_lc ? *logical_clock : received_lc) + 1;
        printf("Process %d received a message. Logical Clock updated to: %d\n", process_id, *logical_clock);
    } else { // Internal event or sending a message
        *logical_clock += 1;
        printf("Process %d performed event %d. Logical Clock updated to: %d\n", process_id, event_id, *logical_clock);
    }
}

// Vector Clock
void vector_clock(int process_id, int event_id, int num_processes, int vector_clock[], int received_vc[]) {
    if (received_vc != NULL) { // Message received
        printf("Process %d received a message.\n", process_id);
        for (int i = 0; i < num_processes; i++) {
            vector_clock[i] = (vector_clock[i] > received_vc[i]) ? vector_clock[i] : received_vc[i];
        }
    }
    vector_clock[process_id] += 1; // Increment local clock
    printf("Process %d performed event %d. Vector Clock updated to: [", process_id, event_id);
    for (int i = 0; i < num_processes; i++) {
        printf("%d", vector_clock[i]);
        if (i < num_processes - 1) printf(", ");
    }
    printf("]\n");
}

int main() {
    int lamport_clocks[NUM_PROCESSES] = {0}; // Initial logical clocks for each process
    int vector_clocks[NUM_PROCESSES][NUM_PROCESSES] = {0}; // Initial vector clocks

    printf("=== Lamport Logical Clocks ===\n");

    // Simulate some events and message passing for Lamport Clock
    lamport_clock(0, 1, &lamport_clocks[0], -1); // Internal event
    lamport_clock(1, 2, &lamport_clocks[1], -1); // Internal event
    lamport_clock(0, 3, &lamport_clocks[0], lamport_clocks[1]); // Message received from Process 1

    printf("\n=== Vector Clocks ===\n");

    // Simulate some events and message passing for Vector Clocks
    int temp_vc[NUM_PROCESSES] = {0};
    vector_clock(0, 1, NUM_PROCESSES, vector_clocks[0], NULL); // Internal event
    vector_clock(1, 2, NUM_PROCESSES, vector_clocks[1], NULL); // Internal event
    memcpy(temp_vc, vector_clocks[1], sizeof(temp_vc)); // Simulate sending message from P1 to P0
    vector_clock(0, 3, NUM_PROCESSES, vector_clocks[0], temp_vc); // Message received by Process 0

    return 0;
}

