#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pwd.h>

#define MAX_FILE_PATH 1024

// Struct to store file information
typedef struct {
    char owner[256];
    long size;
} FileInfo;

// Function to get the owner of a file
char* get_file_owner(struct stat fileStat) {
    struct passwd *pw = getpwuid(fileStat.st_uid);
    if (pw) {
        return pw->pw_name;  // return the owner’s username
    } else {
        return "Unknown";
    }
}

// Function to list files in the current directory and get the largest file size and owners
void find_max_file_and_owners() {
    DIR *d;
    struct dirent *dir;
    struct stat fileStat;
    char current_dir[MAX_FILE_PATH];
    FileInfo maxFileInfo = { "Unknown", 0 };  // Initialize with a default user and size 0
    FileInfo* fileList = malloc(sizeof(FileInfo) * 1000); // Array to store files' info
    int count = 0;

    // Get the current working directory
    if (getcwd(current_dir, sizeof(current_dir)) == NULL) {
        perror("getcwd() failed");
        return;
    }

    // Open the current directory
    d = opendir(current_dir);
    if (d == NULL) {
        perror("opendir() failed");
        return;
    }

    // Read all files in the directory
    while ((dir = readdir(d)) != NULL) {
        // Skip directories
        if (dir->d_type == DT_DIR) {
            continue;
        }

        // Construct the full file path
        char filePath[MAX_FILE_PATH];
        snprintf(filePath, sizeof(filePath), "%s/%s", current_dir, dir->d_name);

        // Get file statistics (size and owner)
        if (stat(filePath, &fileStat) == 0) {
            // Get the file owner
            char* owner = get_file_owner(fileStat);
            // Get the file size
            long size = fileStat.st_size;

            // Save the file info
            fileList[count].size = size;
            strcpy(fileList[count].owner, owner);
            count++;

            // Update the max file size and owners
            if (size > maxFileInfo.size) {
                maxFileInfo.size = size;
                strcpy(maxFileInfo.owner, owner);
            }
        }
    }

    // Find all users who own files of the maximum size
    printf("Users who own the largest file (%ld bytes):\n", maxFileInfo.size);
    for (int i = 0; i < count; i++) {
        if (fileList[i].size == maxFileInfo.size) {
            printf("- %s\n", fileList[i].owner);
        }
    }

    // Clean up
    free(fileList);
    closedir(d);
}

int main() {
    // Run the logic to find max file size and the owners
    find_max_file_and_owners();
    return 0;
}

