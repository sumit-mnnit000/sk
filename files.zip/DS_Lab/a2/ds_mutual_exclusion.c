#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define NUM_PROCESSES 3
#define MAX_QUEUE_SIZE 10

typedef struct {
    int timestamp;
    int process_id;
} Request;

typedef struct {
    Request queue[MAX_QUEUE_SIZE];
    int front, rear;
} RequestQueue;

// Helper functions for the queue
void init_queue(RequestQueue *q) {
    q->front = q->rear = -1;
}

bool is_empty(RequestQueue *q) {
    return q->front == -1;
}

bool is_full(RequestQueue *q) {
    return (q->rear + 1) % MAX_QUEUE_SIZE == q->front;
}

void enqueue(RequestQueue *q, Request req) {
    if (is_full(q)) {
        printf("Queue is full!\n");
        return;
    }
    if (is_empty(q)) q->front = 0;
    q->rear = (q->rear + 1) % MAX_QUEUE_SIZE;
    q->queue[q->rear] = req;
}

Request dequeue(RequestQueue *q) {
    if (is_empty(q)) {
        printf("Queue is empty!\n");
        Request empty = {0, 0};
        return empty;
    }
    Request req = q->queue[q->front];
    if (q->front == q->rear) {
        q->front = q->rear = -1;
    } else {
        q->front = (q->front + 1) % MAX_QUEUE_SIZE;
    }
    return req;
}

void print_queue(RequestQueue *q) {
    if (is_empty(q)) {
        printf("Queue is empty\n");
        return;
    }
    int i = q->front;
    printf("Queue: ");
    while (1) {
        printf("(%d, %d) ", q->queue[i].timestamp, q->queue[i].process_id);
        if (i == q->rear) break;
        i = (i + 1) % MAX_QUEUE_SIZE;
    }
    printf("\n");
}

// Lamport's Mutual Exclusion Algorithm
void lamport_mutex(int process_id, int num_processes, int timestamp) {
    RequestQueue q;
    init_queue(&q);

    printf("Process %d is requesting access to the critical section at timestamp %d\n", process_id, timestamp);

    // Broadcast request
    for (int i = 0; i < num_processes; i++) {
        if (i != process_id) {
            printf("Process %d sends request to Process %d\n", process_id, i);
        }
    }

    // Simulate receiving replies
    for (int i = 0; i < num_processes - 1; i++) {
        printf("Process %d received reply from Process %d\n", process_id, i);
    }

    // Enter critical section
    printf("Process %d is entering the critical section\n", process_id);
    // Simulated critical section work
    printf("Process %d is leaving the critical section\n", process_id);

    // Notify other processes
    for (int i = 0; i < num_processes; i++) {
        if (i != process_id) {
            printf("Process %d notifies Process %d about leaving the critical section\n", process_id, i);
        }
    }
}

// Ricart-Agrawala Mutual Exclusion Algorithm
void ricart_agrawala_mutex(int process_id, int num_processes, int timestamp) {
    printf("Process %d is requesting access to the critical section at timestamp %d\n", process_id, timestamp);

    // Send requests to all other processes
    for (int i = 0; i < num_processes; i++) {
        if (i != process_id) {
            printf("Process %d sends request to Process %d\n", process_id, i);
        }
    }

    // Simulate receiving replies
    for (int i = 0; i < num_processes - 1; i++) {
        printf("Process %d received reply from Process %d\n", process_id, i);
    }

    // Enter critical section
    printf("Process %d is entering the critical section\n", process_id);
    // Simulated critical section work
    printf("Process %d is leaving the critical section\n", process_id);
}

int main() {
    int num_processes = NUM_PROCESSES;

    printf("=== Lamport's Mutual Exclusion Algorithm ===\n");
    lamport_mutex(0, num_processes, 1);

    printf("\n=== Ricart-Agrawala Mutual Exclusion Algorithm ===\n");
    ricart_agrawala_mutex(1, num_processes, 2);

    return 0;
}

