#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <semaphore.h>

#define SHM_NAME "/counter_shm"
#define SEM_NAME "/counter_sem"
#define SHM_SIZE sizeof(int)

int main() {
    // Open shared memory object created by the server
    int shm_fd = shm_open(SHM_NAME, O_RDONLY, S_IRUSR); // Open for read-only access
    if (shm_fd == -1) {
        perror("shm_open failed");
        exit(EXIT_FAILURE);
    }

    // Map shared memory
    int *counter = mmap(NULL, SHM_SIZE, PROT_READ, MAP_SHARED, shm_fd, 0);
    if (counter == MAP_FAILED) {
        perror("mmap failed");
        exit(EXIT_FAILURE);
    }

    // Open the semaphore to synchronize access to the counter
    sem_t *sem = sem_open(SEM_NAME, 0); // Not creating semaphore, just opening it
    if (sem == SEM_FAILED) {
        perror("sem_open failed");
        exit(EXIT_FAILURE);
    }

    printf("Client is running...\n");

    // Access the counter value with synchronization
    for (int i = 0; i < 10; i++) {
        sem_wait(sem); // Wait (lock) semaphore

        // Read and print the current counter value
        printf("Current counter value: %d\n", *counter);

        sem_post(sem); // Post (unlock) semaphore

        sleep(1); // Simulate work
    }

    // Cleanup resources
    munmap(counter, SHM_SIZE);
    close(shm_fd);
    sem_close(sem);

    printf("Client finished.\n");

    return 0;
}

